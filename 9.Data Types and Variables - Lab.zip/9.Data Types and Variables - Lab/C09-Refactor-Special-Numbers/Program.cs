﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C09_Refactor_Special_Numbers
{
    class Program
    {
        static void Main(string[] args)
        {
            int num = int.Parse(Console.ReadLine());
            int sum = 0;
            int number = 0;
            bool specialNumber = false;

            for (int currentNum = 1; currentNum <= num; currentNum++)
            {
                number = currentNum;
                while (number > 0)
                {
                    sum += number % 10;
                    number /= 10;
                }
                specialNumber = (sum == 5) || (sum == 7) || (sum == 11);
                Console.WriteLine($"{currentNum} -> {specialNumber}");
                sum = 0;
            }
        }
    }
}
